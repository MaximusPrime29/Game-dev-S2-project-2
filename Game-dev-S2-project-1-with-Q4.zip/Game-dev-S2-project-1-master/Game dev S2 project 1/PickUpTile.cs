﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_dev_S2_project_1
{
    public abstract class PickUpTile : Tile
    {


        public PickUpTile(Position pos) : base(pos)
        {
        }

        public abstract void ApplyEffect(CharacterTile tar);



    }
}
